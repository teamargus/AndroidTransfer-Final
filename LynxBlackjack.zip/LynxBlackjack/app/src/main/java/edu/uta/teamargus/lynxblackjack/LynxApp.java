package edu.uta.teamargus.lynxblackjack;

import android.app.Activity;
import android.content.Context;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main Activity
 */
public class LynxApp extends Activity {
    private ArrayList<Integer> bit1 = new ArrayList<>();
    private ArrayList<Integer> bit2 = new ArrayList<>();
    private ArrayList<Integer> bit3 = new ArrayList<>();
    private ArrayList<Integer> bit4 = new ArrayList<>();
    private ArrayList<Integer> bit5 = new ArrayList<>();
    private ArrayList<Integer> bit6 = new ArrayList<>();
    private ArrayList<Integer> bit7 = new ArrayList<>();
    private String message="";
    private String binary="0";
    private String temp="";
    private String letter="";
    private String build="";
    private int space =0;

    private int refLeftMargin=300;
    private int refTopMargin=150;
    private Button stay, hit, update, bet10,bet20,bet50,bet100;
    private TextView log;
    private static UsbSerialPort sPort = null;

    private final String TAG = LynxApp.class.getSimpleName();
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();

    private SerialInputOutputManager mSerialIoManager;


    private final SerialInputOutputManager.Listener mListener =
            new SerialInputOutputManager.Listener() {

                @Override
                public void onRunError(Exception e) {
                    Log.d(TAG, "Runner stopped.");
                }

                @Override
                public void onNewData(final byte[] data) {
                    LynxApp.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            LynxApp.this.updateReceivedData(data);
                        }
                    });
                }
            };

    /**
     *Loads UI elements and opens serial port
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Initialize all UI elements and open Serial port
        setContentView(R.layout.activity_lynx_app);
        stay = (Button) findViewById(R.id.stay_button);
        hit = (Button) findViewById(R.id.hit_button);
        bet10 = (Button) findViewById(R.id.bet10);
        bet20 = (Button) findViewById(R.id.bet20);
        bet50 = (Button) findViewById(R.id.bet50);
        bet100 = (Button) findViewById(R.id.bet100);
        update = (Button) findViewById(R.id.update_button);
        log = (TextView) findViewById(R.id.LogBox);
        log.setMovementMethod(new ScrollingMovementMethod());


        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        List<UsbSerialDriver> availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager);
        if (availableDrivers.isEmpty()) {
            return;
        }

        // Open a connection to the first available driver.
        UsbSerialDriver driver = availableDrivers.get(0);
        UsbDeviceConnection connection = manager.openDevice(driver.getDevice());
        if (connection == null) {
            // You probably need to call UsbManager.requestPermission(driver.getDevice(), ..)
            return;
        }
        List<UsbSerialPort> myPortList = driver.getPorts();
        sPort = myPortList.get(0);

        try {
            sPort.open(connection);
            sPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            onDeviceStateChange();
            listenForButton();
        }
        catch(Exception e){
            Log.d("CreateErr",e.toString());
        }
    }

    /**
     * Inflates menu
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.lynx_app, menu);
        return true;
    }

    /**
     * Adds option menu
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings)
            return true;

        return super.onOptionsItemSelected(item);
    }

    /**
     * Listens for button input
     */
    public void listenForButton() {
        /**
         * Update button function
         */
        update.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                build="";
                String card ="_";
                String[] l1 = message.split("\n");
                try {
                    for (int i = 0; i < l1.length; i++) {
                        String[] l2 = l1[i].split(",");
                        for (int w = 0; w < l2.length; w++) {
                            if (l2[w] != null) {
                                bit1.add(Integer.parseInt(l2[0]));
                                bit2.add(Integer.parseInt(l2[1]));
                                bit3.add(Integer.parseInt(l2[2]));
                                bit4.add(Integer.parseInt(l2[3]));
                                bit5.add(Integer.parseInt(l2[4]));
                                bit6.add(Integer.parseInt(l2[5]));
                                bit7.add(Integer.parseInt(l2[6]));
                            }
                        }
                        Arrays.fill(l2, null);
                        //log.setText(list.get(i));

                    }
                    Arrays.fill(l1, null);
                    for (int i = 0; i < bit1.size(); i++) {

                        if (bit1.get(i) > 230) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit2.get(i) > 220) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit3.get(i) > 85) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit4.get(i) > 155) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit5.get(i) > 85) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit6.get(i) > 175) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        if (bit7.get(i) > 175) {
                            binary = binary + "1";
                        } else {
                            binary = binary + "0";
                        }
                        int charCode1 = Integer.parseInt(binary, 2);
                        String str1 = new Character((char) charCode1).toString();
                        temp = temp + str1;

                        // log.append(binary +"\n");
                        binary = "0";

                    }
                    int count = 0;
                    for (int z = 1; z < temp.length(); z++) {
                        if (temp.charAt(z) == temp.charAt(z - 1)) {
                            letter = String.valueOf(temp.charAt(z));
                            count++;
                        } else {
                            if (count > 50) {
                                build = build + String.valueOf(temp.charAt(z - 1));
                                count = 0;
                            }
                        }
                    }
                    if (count > 50) {
                        build = build + letter;
                    }
                    System.out.println(build);
                    //log.setText(build + "\n");

                    log.setText(build);
                }
                catch (Exception e){
                    log.setText("Bad Read");
                }

                if(build.length()==2){
                    switch(build.charAt(1)){
                        case '1':
                            card = card+"10"+"_of_";
                            break;
                        case '2':
                            card = card+"2"+"_of_";
                            break;
                        case '3':
                            card = card+"3"+"_of_";
                            break;
                        case '4':
                            card = card+"4"+"_of_";
                            break;
                        case '5':
                            card = card+"5"+"_of_";
                            break;
                        case '6':
                            card = card+"6"+"_of_";
                            break;
                        case '7':
                            card = card+"7"+"_of_";
                            break;
                        case '8':
                            card = card+"8"+"_of_";
                            break;
                        case '9':
                            card = card+"9"+"_of_";
                            break;
                        case 'j':
                            card = card+"jack"+"_of_";
                            break;
                        case 'q':
                            card = card+"queen"+"_of_";
                            break;
                        case 'k':
                            card = card+"king"+"_of_";
                            break;
                        case 'a':
                            card = card+"ace"+"_of_";
                            break;
                    }
                    switch(build.charAt(0)){
                        case 'H':
                            card = card + "hearts.png";
                            break;
                        case 'S':
                            card = card + "spades.png";
                            break;
                        case 'D':
                            card = card + "diamonds.png";
                            break;
                        case 'C':
                            card = card + "clubs.png";
                            break;
                    }
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(200, 200);
                    layoutParams.leftMargin=refLeftMargin+(space*25);
                    layoutParams.topMargin=refTopMargin;
                    ImageView imageView = new ImageView(getApplicationContext());
                    imageView.setImageResource(getResources().getIdentifier(card, "drawable", getPackageName()));
                    //  imageView.setImageResource(R.drawable._2_of_clubs);
                    imageView.setLayoutParams(layoutParams);
                    RelativeLayout layout = (RelativeLayout)findViewById(R.id.RelaLay);
                    layout.addView(imageView);
                    space++;
                }
                else if(build.length()==4){
                    switch(build.charAt(1)){
                        case '1':
                            card = card+"10"+"_of_";
                            break;
                        case '2':
                            card = card+"2"+"_of_";
                            break;
                        case '3':
                            card = card+"3"+"_of_";
                            break;
                        case '4':
                            card = card+"4"+"_of_";
                            break;
                        case '5':
                            card = card+"5"+"_of_";
                            break;
                        case '6':
                            card = card+"6"+"_of_";
                            break;
                        case '7':
                            card = card+"7"+"_of_";
                            break;
                        case '8':
                            card = card+"8"+"_of_";
                            break;
                        case '9':
                            card = card+"9"+"_of_";
                            break;
                        case 'j':
                            card = card+"jack"+"_of_";
                            break;
                        case 'q':
                            card = card+"queen"+"_of_";
                            break;
                        case 'k':
                            card = card+"king"+"_of_";
                            break;
                        case 'a':
                            card = card+"ace"+"_of_";
                            break;
                    }
                    switch(build.charAt(0)){
                        case 'H':
                            card = card + "hearts.png";
                            break;
                        case 'S':
                            card = card + "spades.png";
                            break;
                        case 'D':
                            card = card + "diamonds.png";
                            break;
                        case 'C':
                            card = card + "clubs.png";
                            break;
                    }
                    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(200, 200);
                    layoutParams.leftMargin=refLeftMargin+(space*25);
                    layoutParams.topMargin=refTopMargin;
                    ImageView imageView = new ImageView(getApplicationContext());
                    imageView.setImageResource(getResources().getIdentifier(card, "drawable", getPackageName()));
                    //  imageView.setImageResource(R.drawable._2_of_clubs);
                    imageView.setLayoutParams(layoutParams);
                    RelativeLayout layout = (RelativeLayout)findViewById(R.id.RelaLay);
                    layout.addView(imageView);
                    space++;
                    card="_";
                    switch(build.charAt(3)){
                        case '1':
                            card = card+"10"+"_of_";
                            break;
                        case '2':
                            card = card+"2"+"_of_";
                            break;
                        case '3':
                            card = card+"3"+"_of_";
                            break;
                        case '4':
                            card = card+"4"+"_of_";
                            break;
                        case '5':
                            card = card+"5"+"_of_";
                            break;
                        case '6':
                            card = card+"6"+"_of_";
                            break;
                        case '7':
                            card = card+"7"+"_of_";
                            break;
                        case '8':
                            card = card+"8"+"_of_";
                            break;
                        case '9':
                            card = card+"9"+"_of_";
                            break;
                        case 'j':
                            card = card+"jack"+"_of_";
                            break;
                        case 'q':
                            card = card+"queen"+"_of_";
                            break;
                        case 'k':
                            card = card+"king"+"_of_";
                            break;
                        case 'a':
                            card = card+"ace"+"_of_";
                            break;
                    }
                    switch(build.charAt(2)){
                        case 'H':
                            card = card + "hearts.png";
                            break;
                        case 'S':
                            card = card + "spades.png";
                            break;
                        case 'D':
                            card = card + "diamonds.png";
                            break;
                        case 'C':
                            card = card + "clubs.png";
                            break;
                    }
                    RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(200, 200);
                    layoutParams2.leftMargin=refLeftMargin+(space*25);
                    layoutParams2.topMargin=refTopMargin;
                    ImageView imageView2 = new ImageView(getApplicationContext());
                    imageView2.setImageResource(getResources().getIdentifier(card, "drawable", getPackageName()));
                    //  imageView.setImageResource(R.drawable._2_of_clubs);
                    imageView.setLayoutParams(layoutParams);
                    RelativeLayout layout2 = (RelativeLayout)findViewById(R.id.RelaLay);
                    layout2.addView(imageView2);
                    space++;
                }
                //log.setText(dec);
                build = "";
                temp = "";
                letter = "";
                binary = "0";
                message = "";
                bit1.clear();
                bit2.clear();
                bit3.clear();
                bit4.clear();
                bit5.clear();
                bit6.clear();
                bit7.clear();
                System.gc();

            }
        });
        /**
         * Bet 10, button function
         */
        bet10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                String msg = "B,10";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }
            }
        });
        /**
         * Bet 20, button function
         */
        bet20.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                String msg = "B,20";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }
            }
        });
        /**
         * Bet 50, button function
         */
        bet50.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                String msg = "B,50";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }
            }
        });
        /**
         * Bet 100, button function
         */
        bet100.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                String msg = "B,100";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }
            }
        });
        /**
         * Stay button function
         */
        stay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String msg = "S,";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }

            }
        });

        /**
         * Hit button function
         */
        hit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String msg = "H,";
                try {
                    sPort.write(msg.getBytes(), 250);
                }
                catch(Exception e){
                    System.err.println(e);
                }
            }

        });
    }

    /**
     * Turns off Serial port
     */
    private void stopIoManager() {
        if (mSerialIoManager != null) {
            Log.i(TAG, "Stopping io manager ..");
            mSerialIoManager.stop();
            mSerialIoManager = null;
        }
    }

    /**
     * Turns on serial port
     */
    private void startIoManager() {
        if (sPort != null) {
            Log.i(TAG, "Starting io manager ..");
            mSerialIoManager = new SerialInputOutputManager(sPort, mListener);
            mExecutor.submit(mSerialIoManager);
        }
    }

    /**
     * When device states changes
     */
    private void onDeviceStateChange() {
        stopIoManager();
        startIoManager();
    }

    /**
     * When application returns to focus
     */
    @Override
    protected void onResume() {

        super.onResume();
        Log.d(TAG, "Resumed, port=" + sPort);
        if (sPort == null) {
            log.setText("No serial device.");
        } else {
            final UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

            UsbDeviceConnection connection = usbManager.openDevice(sPort.getDriver().getDevice());
            if (connection == null) {
                log.setText("Opening device failed");
                return;
            }

            try {
                sPort.open(connection);
                sPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            } catch (IOException e) {
                Log.e(TAG, "Error setting up device: " + e.getMessage(), e);
                log.setText("Error opening device: " + e.getMessage());

                return;
            }
            log.setText("Serial device: " + sPort.getClass().getSimpleName());
        }
        listenForButton();
        onDeviceStateChange();
    }

    /**
     * Gets serial data
     * @param data
     */
    private void updateReceivedData(byte[] data) {

            message = message + new String(data);
    }

    /**
     * Gets card resources
     * @param aClass
     * @return
     * @throws IllegalArgumentException
     */
    private int[] getAllResourceIDs(Class<?> aClass) throws IllegalArgumentException{
                /* Get all Fields from the class passed. */
        Field[] IDFields = aClass.getFields();

                /* int-Array capable of storing all ids. */
        int[] IDs = new int[IDFields.length];

        try {
                        /* Loop through all Fields and store id to array. */
            for(int i = 0; i < IDFields.length; i++){
                                /* All fields within the subclasses of R
                                 * are Integers, so we need no type-check here. */

                // pass 'null' because class is static
                IDs[i] = IDFields[i].getInt(null);
            }
        } catch (Exception e) {
                        /* Exception will only occur on bad class submitted. */
            throw new IllegalArgumentException();
        }
        return IDs;
    }

}
